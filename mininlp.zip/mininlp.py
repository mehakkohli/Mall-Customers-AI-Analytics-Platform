import streamlit as st
import pandas as pd
import numpy as np
from textblob import TextBlob
from sklearn.cluster import KMeans
import plotly.express as px

# -------- THEME CONTROLS -----------
def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
def rgba_css(hex_color, alpha):
    r, g, b = hex_to_rgb(hex_color)
    return f"rgba({r},{g},{b},{alpha})"

if 'theme' not in st.session_state:
    st.session_state.theme = {
        'primary_hex': '#764ba2', 'bg_main_hex': '#f6f9ff', 'card_alpha': 0.95,
        'font_size': 17, 'accent_grad': True
    }

def apply_theme(theme):
    font_size = theme['font_size']
    c = theme
    bg_grad = ("linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%)" if c['accent_grad']
               else c['bg_main_hex'])
    card_bg = rgba_css(c['bg_main_hex'], c['card_alpha'])
    css = f"""
    <style>
    .stApp {{
        background: {bg_grad};
        font-size: {font_size}px !important;
    }}
    .main-container {{
        background-color: {card_bg};
        padding: 2.2rem;
        border-radius: 17px;
        box-shadow: 0 12px 44px rgba(0,0,0,0.10);
        margin: 1.5rem;
        color: #272864;
    }}
    .metric-card {{
        background: linear-gradient(135deg, {c['primary_hex']} 0%, #5578eb 100%);
        color: white; border-radius: 17px;
        padding:1.17rem; margin-bottom:15px; font-weight:bold;
        box-shadow: 0 6px 22px rgba(120,121,230,0.14);
        text-align:center; font-size:22px;
    }}
    .rec-card {{
        background: #fff7e6;
        color: #2d1705;
        border-radius: 13px;
        padding: 1.1em;
        margin: .7em;
        text-align: center;
        font-size: 18px;
        box-shadow: 0 3px 10px #e4dcf3;
        display: inline-block;
        font-weight: 600;
    }}
    .nlp-score {{
        background: #e2f7e1;
        border-radius: 9px;
        color:#206620;
        padding:0.3em 0.7em;
        font-size:1.15em;
        display:inline-block;
        margin:0 .4em 0 .4em;
        font-weight:600;
    }}
    .cluster-badge{{
        color:white;
        padding:0 .75em;
        border-radius:7px;
        font-weight:500;
        font-size:1.1em;
        margin:.2em;
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        display:inline-block;
    }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)
apply_theme(st.session_state.theme)

def theme_ui():
    st.sidebar.header("🎨 Theme Settings")
    col1, col2 = st.sidebar.columns(2)
    card = col1.color_picker("Card bg", st.session_state.theme['bg_main_hex'])
    accent = col2.color_picker("Accent", st.session_state.theme['primary_hex'])
    grad = st.sidebar.toggle("Gradient", value=st.session_state.theme['accent_grad'])
    font_size = st.sidebar.slider("Font Size", 13, 25, st.session_state.theme['font_size'])
    if st.sidebar.button("Apply Theme"):
        st.session_state.theme['bg_main_hex'] = card
        st.session_state.theme['primary_hex'] = accent
        st.session_state.theme['font_size'] = font_size
        st.session_state.theme['accent_grad'] = grad
        apply_theme(st.session_state.theme)
        st.success("Theme updated!")

theme_ui()

# -------- HELPERS -----------
def analyze_sentiment(text):
    blob = TextBlob(str(text))
    pol = blob.sentiment.polarity
    if pol > 0.1: return "Positive"
    elif pol < -0.1: return "Negative"
    else: return "Neutral"
def get_recommendations(age, gender, spend):
    cards = []
    if age < 25:
        cards = [("📱 Smartphone", "Youth favorite: New Android/iPhone models"),
                 ("👟 Sneakers", "Hot trends in sports & casual shoes"),
                 ("🎧 Audio Gear", "Wireless earbuds & headphones"),
                 ("🕹️ Gaming", "Console accessories & games")]
    elif age < 40:
        cards = [("⌚ Fitness Band", "Track workouts & health metrics"),
                 ("💻 Laptop", "Efficient & stylish work devices"),
                 ("🏡 Smart Home", "Latest IoT gadgets")]
    else:
        cards = [("🧳 Travel Kit", "Bags, organizers for frequent travelers"),
                 ("🍲 Kitchen Pro", "Premium kitchen must-haves"),
                 ("🛏️ Relax", "Wellness, pillows, weighted blankets")]
    # Highlight for high-spenders
    if spend > 60: cards[0] = (cards[0][0] + " 🌟", cards[0][1] + " (Premium pick!)")
    return cards

# ---------- MAIN APP -----------
st.markdown("""<div class="main-container">""", unsafe_allow_html=True)
st.markdown("<h1 style='font-size:2.3em;font-weight:900;'>🏬 Mall Customers <span style='color:#764ba2;'>AI Analytics</span> Platform</h1>", unsafe_allow_html=True)
st.caption("Segmentation • Recommendations • 💬 Sentiment • 🛡️ Anomaly • 🔮 Churn — Customizable UI")

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📊 Dashboard", "👥 Segmentation", "🎁 Recommendations", "💬 NLP Insights", "🛡️ Anomaly Detection", "🔮 Churn Prediction"
])

with tab1:
    st.markdown("#### Customer Overview")
    up = st.file_uploader("Upload Customer Dataset (CSV)", type='csv')
    df = None
    if up:
        df = pd.read_csv(up)
        num_customers = len(df)
        avg_age = df['Age'].mean() if 'Age' in df.columns else 0
        avg_income = df['Annual Income (k$)'].mean() if 'Annual Income (k$)' in df.columns else 0
        avg_spend = df['Spending Score (1-100)'].mean() if 'Spending Score (1-100)' in df.columns else 0
        cols = st.columns(4)
        for c, label, val in zip(cols,
             ["Customers", "Avg Age", "Avg Income", "Avg Spending"],
             [num_customers, f"{avg_age:.1f}", f"{avg_income:.0f}k", f"{avg_spend:.1f}"]):
            c.markdown(f'<div class="metric-card">{label}<br><span style="font-size:2rem">{val}</span></div>', unsafe_allow_html=True)
        if {'Annual Income (k$)', 'Spending Score (1-100)', 'Gender'}.issubset(df.columns):
            st.plotly_chart(
                px.scatter(df, x='Annual Income (k$)', y='Spending Score (1-100)', color='Gender',
                    title='Income vs Spending', marginal_x="box", marginal_y="violin"
                ),
                use_container_width=True)
        st.dataframe(df.head(), use_container_width=True)
    else:
        st.info("Upload your mall customers CSV.")

with tab2:
    st.markdown("<h2 style='display:flex;align-items:center'><span style='font-size:1.5em'>👥</span> Customer Segmentation</h2>", unsafe_allow_html=True)
    df_seg = None
    if 'df' in locals() and df is not None:
        n_clusters = st.slider("Number of Clusters", 2, 7, 4)
        if all(col in df.columns for col in ['Annual Income (k$)', 'Spending Score (1-100)', 'Age']):
            X = df[['Annual Income (k$)', 'Spending Score (1-100)']]
            km = KMeans(n_clusters=n_clusters, n_init=10)
            df['Cluster'] = km.fit_predict(X)
            pie = px.pie(df, names='Cluster', hole=0.45,
                         title="Distribution by Cluster", color='Cluster')
            st.plotly_chart(pie, use_container_width=True)
            # Cluster badges/cards
            for i, group in df.groupby('Cluster'):
                st.markdown(
                    f"<span class='cluster-badge'>Cluster {i}</span> "
                    f"Count: {len(group)} | Age: {group['Age'].mean():.1f} | "
                    f"Income: {group['Annual Income (k$)'].mean():.0f}k | "
                    f"Spend: {group['Spending Score (1-100)'].mean():.1f}<br>", 
                unsafe_allow_html=True)
            cluster_selected = st.selectbox("Highlight Cluster", sorted(df['Cluster'].unique()))
            highlight = df.copy()
            highlight['Selected'] = np.where(df['Cluster'] == cluster_selected, 'Target', 'Other')
            st.plotly_chart(px.scatter(
                highlight, x='Annual Income (k$)', y='Spending Score (1-100)', color='Selected',
                symbol='Selected', size='Age', hover_data=['Gender','Age'],
                title=f"Cluster {cluster_selected} Highlighted"), use_container_width=True)
            st.dataframe(df[df['Cluster']==cluster_selected])
            st.download_button("Download this cluster", df[df['Cluster']==cluster_selected].to_csv(index=False), "cluster_data.csv")
        else:
            st.warning("Income and Spending columns required.")

with tab3:
    st.markdown("<h2 style='display:flex;align-items:center'><span style='font-size:1.5em'>🎁</span> Personalized Recommendations</h2>", unsafe_allow_html=True)
    c1, c2, c3 = st.columns(3)
    age = c1.slider('Age', 18, 75, 30)
    gender = c2.radio('Gender', ['Male', 'Female'])
    spend = c3.slider('Spending Score', 1, 100, 50)
    if st.button("Show My Recommendations"):
        st.info(f"Because you are {age}, {gender}, and a {'high' if spend>60 else 'medium' if spend>30 else 'low'} spender.")
        prod_cards = get_recommendations(age, gender, spend)
        card_cols = st.columns(len(prod_cards))
        for col, prod in zip(card_cols, prod_cards):
            icon, desc = prod
            col.markdown(f"<div class='rec-card'><span style='font-size:2em'>{icon}</span><br>{desc}</div>", unsafe_allow_html=True)
        # Similar profile match
        if 'df' in locals() and df is not None and all(col in df.columns for col in ['Age','Spending Score (1-100)']):
            sim_customers = df[(df['Age'].between(age-3, age+3)) & (df['Spending Score (1-100)'].between(spend-10,spend+10))]
            st.write("**Customers like you:**")
            st.dataframe(sim_customers.sample(min(3, len(sim_customers))))
        st.success("You can also download your recommendation as a PDF report soon (feature coming)!")

with tab4:
    st.markdown("<h2 style='display:flex;align-items:center'><span style='font-size:1.5em'>💬</span> NLP Insights: Sentiment Analysis</h2>", unsafe_allow_html=True)
    st.write("Upload reviews with a 'Review' column or enter feedback below. Visualizes and scores sentiment distribution.")
    rev_file = st.file_uploader("Upload Reviews CSV", type='csv', key='nlp')
    if rev_file:
        df_rev = pd.read_csv(rev_file)
        if 'Review' in df_rev.columns:
            df_rev['Sentiment'] = df_rev['Review'].apply(analyze_sentiment)
            pos = (df_rev['Sentiment']=='Positive').mean()*100
            neu = (df_rev['Sentiment']=='Neutral').mean()*100
            neg = (df_rev['Sentiment']=='Negative').mean()*100
            st.progress(int(pos), text=f"Positive: {pos:.1f}%")
            st.progress(int(neu), text=f"Neutral: {neu:.1f}%")
            st.progress(int(neg), text=f"Negative: {neg:.1f}%")
            st.plotly_chart(px.pie(df_rev, names='Sentiment', hole=0.45, color='Sentiment',
                                   title="Sentiment Breakdown"), use_container_width=True)
            st.write("Sample Reviews:")
            for _, row in df_rev.sample(min(4, len(df_rev))).iterrows():
                senti = row['Sentiment']
                tag = "👍" if senti == "Positive" else "😐" if senti == "Neutral" else "😞"
                st.markdown(f"<span class='nlp-score'>{tag} {senti}</span> - <i>{row['Review']}</i>", unsafe_allow_html=True)
        else:
            st.error("CSV must have a 'Review' column.")
    else:
        rtxt = st.text_area("Type a review")
        if st.button("Analyze Sentiment"):
            st.info(f"Sentiment: {analyze_sentiment(rtxt)}")

with tab5:
    st.markdown("<h2 style='display:flex;align-items:center'><span style='font-size:1.5em'>🛡️</span> Anomaly Detection</h2>", unsafe_allow_html=True)
    if 'df' in locals() and df is not None:
        required_cols = ['Age', 'Annual Income (k$)', 'Spending Score (1-100)']
        if all(col in df.columns for col in required_cols):
            from sklearn.ensemble import IsolationForest
            Xanom = df[required_cols]
            iso = IsolationForest(contamination=0.07)
            df['anomaly'] = iso.fit_predict(Xanom)
            out_count = (df['anomaly']==-1).sum()
            st.metric("Outlier Count", out_count)
            st.plotly_chart(
                px.scatter(
                    df, x='Annual Income (k$)', y='Spending Score (1-100)',
                    color=df['anomaly'].map({1:'Normal',-1:'Outlier'}),
                    title="Anomalies (Outlier Detection)"),
                    use_container_width=True)
            st.dataframe(df[df['anomaly']==-1])
        else:
            st.warning("Dashboard must have Age, Income, Spending columns.")
    else:
        st.info("Upload your customer dataset in the Dashboard tab.")

with tab6:
    st.markdown("<h2 style='display:flex;align-items:center'><span style='font-size:1.5em'>🔮</span> Churn Prediction</h2>", unsafe_allow_html=True)
    st.caption("Simulates churn prediction for uploaded data.")
    if 'df' in locals() and df is not None and all(c in df.columns for c in ['Age', 'Annual Income (k$)', 'Spending Score (1-100)']):
        st.write("Churn = likely to leave (older, low spenders demo rule only).")
        df['Churn'] = ((df['Spending Score (1-100)']<30) & (df['Age']>45)).astype(int)
        X = df[['Age','Annual Income (k$)','Spending Score (1-100)']]
        y = df['Churn']
        from sklearn.ensemble import RandomForestClassifier
        from sklearn.metrics import confusion_matrix, classification_report
        clf = RandomForestClassifier()
        clf.fit(X, y)
        preds = clf.predict(X)
        cm = confusion_matrix(y, preds)
        st.write("Confusion Matrix:")
        st.dataframe(pd.DataFrame(cm,columns=['Stay','Churn'],index=['Stay','Churn']))
        st.write("Classification Report:")
        st.code(classification_report(y, preds), language="text")
        age_pred = st.number_input("Age", 18,80,30)
        inc_pred = st.number_input("Income (k$)", 10,250,65)
        spend_pred = st.number_input("Spending",1,100,45)
        if st.button("Predict Churn"):
            one = np.array([[age_pred, inc_pred, spend_pred]])
            pred = clf.predict(one)[0]
            if pred==1:
                st.error("Likely Churn 😢")
            else:
                st.success("Likely to Stay 😀")
    else:
        st.warning("Upload dataset with Age, Income, Spending.")

st.markdown("</div>", unsafe_allow_html=True)
